const express = require("express");

const app = express();

app.use(logger);

app.get("/books",function(req,res){
    res.send({name: "harry potter"});
});



app.get("/libraries",checkPermission("librariran"),(req,res)=>{
   return res.send({library: "school library"});
});

app.get("/authors",checkPermission("author"),(req,res)=>{
   return res.send({author: "harry potter"});
});


function logger(req,res,next){
    console.log(req.path);
    next();
}
function checkPermission(user){

    return function user(req,res,next){
      if(user === "librarian"){
        if(req.path==="/libraries"){
            req.permission = "true";
        }
      }
      else {
          if(user ==="author"){
            if(req.path==="/authors"){
                req.permission = "true"
            }
      }
    }
    next();
}
    
}


app.listen(5000,()=>{
console.log("listening on port 5000")
});